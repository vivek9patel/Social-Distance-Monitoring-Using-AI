<?php
    session_start();
    if(isset($_SESSION["mobile_num"])){
        $num=$_SESSION["mobile_num"];
    }
    else{
        echo "<script>window.location.href='http://indiafightscovid19.000webhostapp.com';</script>";
    }

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="module" src="https://cdn.jsdelivr.net/npm/@ionic/core/dist/ionic/ionic.esm.js"></script>
    <script nomodule src="https://cdn.jsdelivr.net/npm/@ionic/core/dist/ionic/ionic.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@ionic/core/css/ionic.bundle.css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
    
    <style>
    :root {
      --ion-safe-area-top: 0px;
      --ion-safe-area-bottom: 22px;
    }
    
  </style>
  <script type="module">
    import { alertController } from 'https://cdn.jsdelivr.net/npm/@ionic/core@next/dist/ionic/index.esm.js';
    window.alertController = alertController;
  </script>
    
</head>
<body>
    
    <ion-app>
    
    <ion-tabs>

    <ion-tab tab="tab-home">
    <ion-header translucent>
          <ion-toolbar>
            <ion-title class="ion-text-center" color="tertiary"><h2>COVID-19 Fight</h2></ion-title>
          </ion-toolbar>
        </ion-header>
        
        <ion-content class="ion-padding-top ion-padding-bottom">
            <ion-fab horizontal="end" vertical="bottom" slot="fixed">
        <ion-fab-button color="success" id="whatsapp">
          <ion-icon name="logo-whatsapp"></ion-icon>
        </ion-fab-button>
      </ion-fab>
            <ion-card>
                <img src="img/1.jpg" />
                <ion-card-header>
                  <ion-card-subtitle></ion-card-subtitle>
                  <ion-card-title>If you will go outside, Corona will come inside! </ion-card-title>
                </ion-card-header>
            </ion-card>
            <ion-card>
                <img src="img/2.jpg" />
                <ion-card-header>
                  <ion-card-subtitle></ion-card-subtitle>
                  <ion-card-title>Only bridge between Corona & You is your hands. Wash Them! </ion-card-title>
                </ion-card-header>
            </ion-card>
            <ion-card>
                <img src="img/3.jpg" />
                <ion-card-header>
                  <ion-card-subtitle></ion-card-subtitle>
                  <ion-card-title>Social Distance is the only weapon to fight COVID-19</ion-card-title>
                </ion-card-header>
            </ion-card>
            <ion-card>
                <img src="img/4.jpeg" />
                <ion-card-header>
                  <ion-card-subtitle></ion-card-subtitle>
                  <ion-card-title>Follow the guidelines given by Government and Police</ion-card-title>
                </ion-card-header>
            </ion-card>
        </ion-content>
    </ion-tab>
    
    <ion-tab tab="tab-case">
    <ion-header translucent>
          <ion-toolbar>
            <ion-title class="ion-text-center" color="tertiary"><h2>COVID-19 Fight</h2></ion-title>
          </ion-toolbar>
        </ion-header>
        
        
        
        <ion-content class="ion-padding">
            
            <ion-fab horizontal="end" vertical="bottom" slot="fixed">
        <ion-fab-button color="primary" id="call" href="tel:91-11-23978046">
          <ion-icon name="call-outline"></ion-icon>
        </ion-fab-button>
      </ion-fab>
            <ion-card>
                <ion-card-header>
                  <ion-card-subtitle>Infected</ion-card-subtitle>
                  <ion-card-title><h2 class="count">5,734</h2></ion-card-title>
                </ion-card-header>
                <ion-card-content>
                  Number of active cases of COVID-19
                </ion-card-content>
                <ion-progress-bar color="warning" value="1"></ion-progress-bar>
            </ion-card>
            <ion-card class="ion-padding-top">
                <ion-card-header>
                  <ion-card-subtitle>Recovered</ion-card-subtitle>
                  <ion-card-title><h2 class="count">473</h2></ion-card-title>
                </ion-card-header>
                <ion-card-content>
                  Number of recoveries from COVID-19
                </ion-card-content>
                <ion-progress-bar color="success" value="1"></ion-progress-bar>
            </ion-card>
            <ion-card class="ion-padding-top">
                <ion-card-header>
                  <ion-card-subtitle>Deaths</ion-card-subtitle>
                  <ion-card-title><h2 class="count">166</h2></ion-card-title>
                </ion-card-header>
                <ion-card-content>
                  Number of deaths caused by COVID-19
                </ion-card-content>
                <ion-progress-bar color="danger" value="1"></ion-progress-bar>
            </ion-card>
            <ion-button expand="block" shape="round" color="tertiary" horizontal="end" vertical="bottom"><b>Help Nation by Donation</b></ion-button>
        </ion-content>
    </ion-tab>
  
    <ion-tab tab="tab-request" ng-app="myApp">
         <ion-toolbar>
        <ion-segment value="all">
          <ion-segment-button value="all" id="gReq">General Request</ion-segment-button>
          <ion-segment-button value="favorites" id="sReq">Social Distance Request</ion-segment-button>
        </ion-segment>
      </ion-toolbar>

        <ion-content fullscreen class="ion-padding-top" id="greq">
            
            <ion-card>
                <ion-card-header>
                    <ion-card-title>General Request</ion-card-title>
                </ion-card-header>
    
                <ion-card-content>
                <form id="generalReq">    
                        <ion-item>
                            <ion-label>State</ion-label>
                                <ion-select placeholder="Select" id="state" value="">
                                    <ion-select-option value="andhra pradesh">Andhra Pradesh</ion-select-option>
                                    <ion-select-option value="goa">Goa</ion-select-option>
                                    <ion-select-option value="gujarat">Gujarat</ion-select-option>
                                    <ion-select-option value="haryana">Haryana</ion-select-option>
                                    <ion-select-option value="kerala">Kerala</ion-select-option>
                                    <ion-select-option value="madhya Pradesh">Madhya Pradesh</ion-select-option>
                                    <ion-select-option value="maharashtra">Maharashtra</ion-select-option>
                                    <ion-select-option value="punjab">Punjab</ion-select-option>
                                    <ion-select-option value="rajasthan">Rajasthan</ion-select-option>
                                </ion-select>
                        </ion-item>
                        
                        <ion-item>
                            <ion-label>City</ion-label>
                                <ion-select placeholder="Select" id="city2" value="">
                                    <ion-select-option></ion-select-option>
                                </ion-select>
                        </ion-item>
                        
                        <ion-item>
                            <ion-label position="floating"><h2>Pincode</h2></ion-label>
                            <ion-input id="pincode2" type="number" maxlength="6"></ion-input>
                        </ion-item>
                        
                        <ion-item>
                            <ion-label>Problem</ion-label>
                                <ion-select placeholder="Select" id="problem" value="">
                                    <ion-select-option value="cleanliness">cleanliness</ion-select-option>
                                    <ion-select-option value="health">health</ion-select-option>
                                    <ion-select-option value="grocery">grocery</ion-select-option>
                                    <ion-select-option value="need vegetables">Need vegetable</ion-select-option>
                                    <ion-select-option value="medicine">medicine</ion-select-option>
                                </ion-select>
                        </ion-item>
                        
                        <ion-item>
                            <ion-label position="floating">Description</ion-label>
                            <ion-textarea id="discription"></ion-textarea>
                        </ion-item>
                    
                        <ion-button id="greqsend" class="ion-float-right ion-margin" color="success" fill="outline">Send</ion-button>
                </form>
                <ion-progress-bar type="indeterminate" id="img-loader2"></ion-progress-bar>
              </ion-card-content>
            </ion-card>
            
            <ion-button expand="full" fill="outline" color="dark">Your Request</ion-button>
            
            <div ng-controller="myCtrl">
            <ion-card ng-repeat="x in myData">
                <ion-card-header>
                    <ion-card-subtitle>Date {{x.date1}}</ion-card-subtitle>
                    <ion-card-title>Problem {{x.problem}} </ion-card-title>
                </ion-card-header>

                <ion-card-content>
                    Description {{x.description}}
                </ion-card-content>
            </ion-card>
            </div>
        </ion-content>
        
        
        <ion-content fullscreen class="ion-padding-top" id="sreq">
            
            <ion-card>
                <ion-card-header>
                    <ion-card-title>Request for Social Distance</ion-card-title>
                </ion-card-header>
    
                <ion-card-content>
                <form id="uploadForm" enctype="multipart/form-data">    
                        <ion-item>
                            <ion-label position="floating"><h2>Enter City</h2></ion-label>
                            <ion-input id="city" type="text"></ion-input>
                        </ion-item>
                        
                        <ion-item>
                            <ion-label position="floating"><h2>Pincode</h2></ion-label>
                            <ion-input id="pincode" type="number" maxlength="6"></ion-input>
                        </ion-item>
                        
                        <ion-item>
                            <ion-label position="fixed"><h2>Upload Image</h2></ion-label>
                            <input id="file" type="file" accept="image/*" name="file">
                        </ion-item>
                        <ion-item>
                            <ion-label position="floating">Area Description</ion-label>
                            <ion-textarea id="adisp"></ion-textarea>
                        </ion-item>
                    
                        <ion-button id="upload" class="ion-float-right ion-margin" color="success" fill="outline">Send</ion-button>
                </form>
                <ion-progress-bar type="indeterminate" id="img-loader"></ion-progress-bar>
              </ion-card-content>
            </ion-card>
            
            <ion-button expand="full" fill="outline" color="dark">Your Requests</ion-button>
            
            <div ng-controller="uploadCONTROL">
            <ion-card ng-repeat="x2 in myData2">
                <img src="{{x2.img}}"/>
                    <ion-card-header>
                        <ion-card-subtitle>Date:{{x2.date}}</ion-card-subtitle>
                    </ion-card-header>
                   
            </ion-card>
            </div>
            
        </ion-content>
        
        
        
    </ion-tab>

  <ion-tab tab="tab-about" component="page-about">
    <ion-header translucent>
          <ion-toolbar>
            <ion-title class="ion-text-center" color="tertiary"><h2>COVID-19 Fight</h2></ion-title>
          </ion-toolbar>
        </ion-header>
        
        <ion-content fullscreen>
            
        <ion-list>
        <ion-list-header>
          <ion-label><h1>Your Details</h1></ion-label>
            <ion-icon name="person-circle-outline" slot="end"></ion-icon>
        </ion-list-header>
       
        <ion-item>
            <ion-label>
                <h3>Number</h2>
                <h2><ion-icon name="call-outline" ></ion-icon>&nbsp;<?php echo $num;?></h2>
            </ion-label>
          </ion-item>
          <ion-item>
            <ion-label>
                <h2 id="logout"><ion-icon name="log-out-outline"></ion-icon>&nbsp;Logout</h2>
            </ion-label>
            </ion-item>
      </ion-list>


        <ion-list>
        <ion-list-header>
          <ion-label><h1>Helpline</h1></ion-label>
        </ion-list-header>
       
        <ion-item>
            <ion-label>
                <h3>Help Line Number</h2>
                <h2><ion-icon name="call-outline" ></ion-icon>&nbsp;+91-11-23978046</h2>
                <h2><ion-icon name="call-outline" ></ion-icon>&nbsp;1075</h2>
            </ion-label>
          </ion-item>
          <ion-item>
            <ion-label>
                <h3>Email</h3>
                <h2 id="em"><ion-icon name="log-out-outline"></ion-icon>&nbsp;ncov2019@gov.in </h2>
            </ion-label>
            </ion-item>
            <ion-item>
            <ion-label>
                <h3>Whatsapp</h3>
                <h2 id="wht"><ion-icon name="logo-whatsapp"></ion-icon>&nbsp;+919013151515</h2>
            </ion-label>
            </ion-item>
      </ion-list>
         
        </ion-content>
  </ion-tab>

  <ion-tab-bar slot="bottom">
    
    <ion-tab-button tab="tab-home">
      <ion-icon name="home-outline"></ion-icon>
      <ion-label>Home</ion-label>
    </ion-tab-button>
    
    <ion-tab-button tab="tab-case">
      <ion-icon name="stats-chart-outline"></ion-icon>
      <ion-label>Cases</ion-label>
    </ion-tab-button>
    
    <ion-tab-button tab="tab-request">
      <ion-icon name="add-circle-outline"></ion-icon>
      <ion-label>Complain</ion-label>
    </ion-tab-button>

    <ion-tab-button tab="tab-about">
      <ion-icon name="information-circle"></ion-icon>
      <ion-label>About</ion-label>
    </ion-tab-button>
  </ion-tab-bar>

    </ion-tabs>
    
 </ion-app>


    <script>
        $(document).ready(function (e){
            
            $("#img-loader").hide();
            $("#img-loader2").hide();
            $("#sreq").hide();
            $("#greq").show();
            
            $("#gReq").on('click',(function(){
                $("#img-loader").hide();
                $("#sreq").hide();
                $("#greq").show();
            }));
            
            $('#whatsapp').on('click',function(){
                location.replace("https://wa.me/919013151515");
            });
            
            $("#sReq").on('click',(function(){
                $("#img-loader").hide();
                $("#greq").hide();
                $("#sreq").show();
            }));
            
            async function uploadMsg() {
                const alert = await alertController.create({
                        header: '',
                        message: 'Request sent successfully',
                        buttons: ['ok']
                });
                await alert.present();
            }
            
                $("#state").on('ionChange',function(){
                const st = document.getElementById("state").value;
                //console.log(st);
                
                $.ajax({
                   method:"POST",
                   url:"stateToCity.php",
                   data:{statename:st},
                   dataType:"html",
                   success:function(data){
                       $("#city2").html(data);
                   }
                });
            });
            
            $("#greqsend").on('click',function(){
               let state = document.getElementById("state").value;
               let city2 = document.getElementById("city2").value;
               let pincode2 = document.getElementById("pincode2").value;
               var problem = document.getElementById("problem").value;
               let discription = document.getElementById("discription").value;
               
               var x = problem.toString();
               
               if(state != '' || city2 != '' || pincode2 != '' || problem != ''){
                   
                   $.ajax({
                        url: "grequest.php",
                         method: "POST",
                        data:{gstate:state,gcity2:city2,gpincode2:pincode2,gproblem:x,gdiscription:discription},
                        beforeSend: function(){
				            $('#generalReq').css("opacity",".5");
				            $("#img-loader2").show();
			                  },
                        success: function(data){
                            $("#img-loader2").hide();
                            $('#generalReq').css("opacity","1");
                            uploadMsg();
                        },
                        error: function(){}
                   });
               }
               else
               {
                   async function ci8() {
                        const alert = await alertController.create({
                        header: 'Please select',
                        message: 'You must have to select state,city,pincode,problem',
                        buttons: ['ok']
                    });
                    
                    await alert.present();
                    }
                    ci8();
               }
               
            });
            
            $("#upload").on('click',(function(e){
                
                e.preventDefault();
                
                var city = document.getElementById("city").value;
                var pincode = document.getElementById("pincode").value;
                var adisp = document.getElementById("adisp").value;
                var str = document.getElementById("file").value;
                var extArray = str.split(".");
                var ext = extArray[extArray.length - 1];
                const chkArr = ['jpg','jpeg','png'];
                
                if(city != ''){
                    if(pincode != ''){
                        if(chkArr[0] == ext || chkArr[1] == ext || chkArr[2] == ext ){
                            
                            var fd = new FormData();
                            var files = $('#file')[0].files[0];
                            fd.append('file',files);
                            fd.append('city',city);
                            fd.append('pincode',pincode);
                            fd.append('adisp',adisp);
                    
                            $.ajax({
                                url: "upload.php",
                                type: "POST",
                                data: fd,
                                contentType: false,
                                cache: false,
                                processData:false,
                                beforeSend: function(){
				                    $('#uploadForm').css("opacity",".5");
				                    $("#img-loader").show();
			                    },
                                success: function(data){
                                    $("#img-loader").hide();
                                    $('#uploadForm').css("opacity","1");
                                    uploadMsg();
                                },
                                error: function(){} 	        
                            });
                        }
                        else{
                            
                            async function ci() {
                            const alert = await alertController.create({
                                header: 'Image',
                                message: 'You must have to upload image',
                                buttons: ['ok']
                            });
                    
                            await alert.present();
                            }
                            ci();
                        }
                    }
                    else{
                        
                        async function ci1() {
                        const alert = await alertController.create({
                                header: 'Pincode',
                                message: 'Please enter pincode',
                                buttons: ['ok']
                        });
                    
                            await alert.present();
                        }
                        ci1();
                        
                    }
                }
                else{
                    
                        async function ci2() {
                        const alert = await alertController.create({
                            header: 'City',
                            message: 'Please enter city',
                            buttons: ['ok']
                        });
                    
                            await alert.present();
                        }
                        ci2();
                }
        
            }));
            
            $('#logout').on('click',(function(){
                location.replace("http://indiafightscovid19.000webhostapp.com/logout1.php");
            }));
            
        });
        
        
        var app = angular.module('myApp', []);
        //function optdata(){
         app.controller('myCtrl', ['$scope', '$http', function ($scope, $http) {
            $http({
              method: 'get',
              url: 'greqFetch.php'
             }).then(function successCallback(response) {
              $scope.myData = response.data;
             });
            }]);
       // }
            //optdata();
            
           /* app.controller('myCtrl', ['$scope', function($scope) {
                    $scope.myFunc = function() {
               optdata();
            };
            }]);*/
           /* app.controller('myCtrl', ['$scope', '$http', function ($scope, $http) {
                $scope.myFunc = function() {
                    $http({
                    method: 'get',
                    url: 'greqFetch.php'
                    }).then(function successCallback(response) {
                    $scope.myData = response.data;
                    });
                };
            }]);*/
            
          
            app.controller('uploadCONTROL', ['$scope', '$http', function ($scope, $http) {
            $http({
              method: 'get',
              url: 'uploadFetch.php'
             }).then(function successCallback(response) {
                
                $scope.myData2 = response.data;

             });
            }]);
    </script>         
    
    <script>
         
    </script>    

</body>
</html>