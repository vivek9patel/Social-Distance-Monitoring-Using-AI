<?php

    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");

    include 'connect.php';

    session_start();
    $accid='';
    if(isset($_SESSION['google_email'])){
        $accid=$_SESSION['google_email'];
    }
    else if(isset($_SESSION["mobile_num"])){
        $accid=$_SESSION["mobile_num"];
    }

    $q="SELECT problem,description,date1 FROM `greq` WHERE acc = '9824460935'";
    $cmd=mysqli_query($con,$q);
    
    $data = array();
    
    while ($row = mysqli_fetch_array($cmd)){
        $data[] = array("problem"=>$row['problem'],"description"=>$row['description'],"date1"=>$row['date1']);
        //print_r($data);
    }
    echo json_encode($data);
?>