<?php
    
        session_start();
        $accid='';
        if(isset($_SESSION['google_email'])){
            $accid=$_SESSION['google_email'];
        }
        else if(isset($_SESSION["mobile_num"])){
            $accid=$_SESSION["mobile_num"];
        }
        
        include 'connect.php';
        $gstate="";
        $gcity2="";
        $gpincode2="";
        $gproblem="";
        $gdiscription="";
        //$dt=date("Y-m-d");
        
        $gstate=$_POST['gstate'];
        $gcity2=$_POST['gcity2'];
        $gpincode2=$_POST['gpincode2'];
        $gproblem=$_POST['gproblem'];
        $gdiscription=$_POST['gdiscription'];
        
        $q="INSERT INTO `greq`(`state`, `city`, `pincode`, `problem`, `description`,`acc`, `date1`) VALUES ('$gstate','$gcity2',$gpincode2,'$gproblem','$gdiscription','$accid',NOW())";
        $cmd=mysqli_query($con,$q);
        
    

?>