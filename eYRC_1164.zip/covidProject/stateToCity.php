<?php

    $zid=$_POST["statename"];
    
    
        if($zid == 'andhra pradesh'){
            echo "<ion-select placeholder='Select' id='city2' value=''>";
            echo "<ion-select-option value='anantapur'>Anantapur</ion-select-option>";
            echo "<ion-select-option value='dharmavaram'>Dharmavaram</ion-select-option>";
            echo "<ion-select-option value='kurnool'>Kurnool</ion-select-option>";
            echo "<ion-select-option value='visakhapatnam'>Visakhapatnam</ion-select-option>";
            echo "<ion-select-option value='vizianagaram'>Vizianagaram</ion-select-option>";
            echo "</ion-select>";
        }
        else if($zid == 'goa'){
            echo "<ion-select placeholder='Select' id='city2' value=''>";
            echo "<ion-select-option value='canacona'>Canacona</ion-select-option>";
            echo "<ion-select-option value='margao'>Margao</ion-select-option>";
            echo "<ion-select-option value='panaji'>Panaji</ion-select-option>";
            echo "</ion-select>";
        }
        else if($zid == 'gujarat'){
            echo "<ion-select placeholder='Select' id='city2' value=''>";
            echo "<ion-select-option value='ahmedabad'>Ahmedabad</ion-select-option>";
            echo "<ion-select-option value='bhavnagar'>Bhavnagar</ion-select-option>";
            echo "<ion-select-option value='rajkot'>Rajkot</ion-select-option>";
            echo "<ion-select-option value='surat'>Surat</ion-select-option>";
            echo "<ion-select-option value='vadodara'>Vadodara</ion-select-option>";
            echo "</ion-select>";
        }
        else if($zid == 'haryana'){
            echo "<ion-select placeholder='Select' id='city2' value=''>";
            echo "<ion-select-option value='faridabad'>Faridabad</ion-select-option>";
            echo "<ion-select-option value='gurugram'>Gurugram</ion-select-option>";
            echo "<ion-select-option value='panipat'>Panipat</ion-select-option>";
            echo "<ion-select-option value='rohtak'>Rohtak</ion-select-option>";
            echo "<ion-select-option value='yamunanagar'>Yamunanagar</ion-select-option>";
            echo "</ion-select>";
        }
        else if($zid == 'kerala'){
            echo "<ion-select placeholder='Select' id='city2' value=''>";
            echo "<ion-select-option value='alappuzha'>Alappuzha</ion-select-option>";
            echo "<ion-select-option value='kannur'>Kannur</ion-select-option>";
            echo "<ion-select-option value='kochi'>Kochi</ion-select-option>";
            echo "<ion-select-option value='kollam'>Kollam</ion-select-option>";
            echo "<ion-select-option value='varkala'>Varkala</ion-select-option>";
            echo "</ion-select>";
        }
        else if($zid == 'madhya Pradesh'){
            echo "<ion-select placeholder='Select' id='city2' value=''>";
            echo "<ion-select-option value='bhopal'>Bhopal</ion-select-option>";
            echo "<ion-select-option value='indore'>Indore</ion-select-option>";
            echo "<ion-select-option value='jabalpur'>Jabalpur</ion-select-option>";
            echo "<ion-select-option value='singrauli'>Singrauli</ion-select-option>";
            echo "<ion-select-option value='ujjain'>Ujjain</ion-select-option>";
            echo "</ion-select>";
        }
        else if($zid == 'maharashtra'){
            echo "<ion-select placeholder='Select' id='city2' value=''>";
            echo "<ion-select-option value='aurangabad '>Aurangabad </ion-select-option>";
            echo "<ion-select-option value='kolhapur'>Kolhapur</ion-select-option>";
            echo "<ion-select-option value='nashik'>Nashik</ion-select-option>";
            echo "<ion-select-option value='navi Mumbai'>Navi Mumbai</ion-select-option>";
            echo "<ion-select-option value='pune'>Pune</ion-select-option>";
            echo "</ion-select>";
        }
        else if($zid == 'punjab'){
            echo "<ion-select placeholder='Select' id='city2' value=''>";
            echo "<ion-select-option value='amritsar'>Amritsar</ion-select-option>";
            echo "<ion-select-option value='firozpur'>Firozpur</ion-select-option>";
            echo "<ion-select-option value='jalandhar'>Jalandhar</ion-select-option>";
            echo "<ion-select-option value='mohali'>Mohali</ion-select-option>";
            echo "<ion-select-option value='patiala'>Patiala</ion-select-option>";
            echo "</ion-select>";
        }
        else if($zid == 'rajasthan'){
            echo "<ion-select placeholder='Select' id='city2' value=''>";
            echo "<ion-select-option value='ajmer'>Ajmer</ion-select-option>";
            echo "<ion-select-option value='bikaner'>Bikaner</ion-select-option>";
            echo "<ion-select-option value='jaipur'>Jaipur</ion-select-option>";
            echo "<ion-select-option value='kota'>Kota</ion-select-option>";
            echo "<ion-select-option value='udaipur'>Udaipur</ion-select-option>";
            echo "</ion-select>";
        }
        else{
            echo "<ion-select placeholder='Select' id='city2' value=''>";
            echo "<ion-select-option value=''>NULL</ion-select-option>";
            echo "</ion-select>";
        }

?>