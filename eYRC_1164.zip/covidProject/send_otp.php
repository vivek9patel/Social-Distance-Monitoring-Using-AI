<?php
if(isset($_POST["mobile_number"]))
    {
        session_start();
        $mob=$_POST["mobile_number"];
        $_SESSION["mobile_num"]=$mob;
       
        $url="https://www.sms4india.com/api/v1/sendCampaign";
        $x=mt_rand(12344,98999);
        $_SESSION["otp"]=$x;
        $xyz="Your OTP is ".$x;
        //echo $xyz;
        $message = urlencode($xyz);
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, "apikey=NGPIFONYW76KKHGNA12FEKMRBPD0I3LZ&secret=IN8ZR5CEXP0QH4M1&usetype=stage&phone=$mob&senderid=[active-sender-id]&message=$message");
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($curl);
        curl_close($curl);
        
        echo $_SESSION['otp'];
    
    }
?>