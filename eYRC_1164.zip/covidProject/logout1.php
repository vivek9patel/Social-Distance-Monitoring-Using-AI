<?php
session_start();

session_unset();

echo "<script>location.replace('http://indiafightscovid19.000webhostapp.com')</script>";
?>