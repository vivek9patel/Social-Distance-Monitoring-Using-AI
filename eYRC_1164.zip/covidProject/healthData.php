<?php

    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");

    include 'connect.php';

    $q="SELECT  `state`, `city`, `pincode`, `problem`, `description`, `acc`, `date1` FROM `greq`";
    $cmd=mysqli_query($con,$q);
    
    $data = array();
    
    while ($row = mysqli_fetch_array($cmd)){
        $data[] = array("state"=>$row['state'],"city"=>$row['city'],"pincode"=>$row['pincode'],"problem"=>$row['problem'],"description"=>$row['description'],"acc"=>$row['acc'],"date1"=>$row['date1']);
        //print_r($data);
    }
    echo json_encode($data);
?>