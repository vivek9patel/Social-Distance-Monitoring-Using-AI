<?php
	session_start();
	require_once "GoogleAPI/vendor/autoload.php";
	$gClient = new Google_Client();
	$gClient->setClientId("608823307769-a971gknk5eomv4lc9ajfqnqkaee28qd1.apps.googleusercontent.com");
	$gClient->setClientSecret("2Pr3lTVFrdIZPmUTIR8OyjXb");
	$gClient->setApplicationName("COVID-19");
	$gClient->setRedirectUri("http://indiafightscovid19.000webhostapp.com/main2.php");
	$gClient->addScope("https://www.googleapis.com/auth/plus.login https://www.googleapis.com/auth/userinfo.email");
?>
