<?php
    
    include 'connect.php';
    
    session_start();
        $accid='';
    if(isset($_SESSION['google_email'])){
        $accid=$_SESSION['google_email'];
    }
    else if(isset($_SESSION["mobile_num"])){
        $accid=$_SESSION["mobile_num"];
    }
    
    $city=$_POST['city'];
    $pincode=$_POST['pincode'];
    $adisp=$_POST['adisp'];
    $file=$_FILES['file'];
    
    $filename = $_FILES['file']['name'];
    $location = 'complain/'.$filename;
    $loc2 = 'cc/'.$filename;
    
    compressedImage($_FILES['file']['tmp_name'],$loc2,60);
    move_uploaded_file($_FILES['file']['tmp_name'],$location);
    
    
    $exif=exif_read_data($location);
    $ts=$exif['DateTimeOriginal'];
    $lon = getGps($exif["GPSLongitude"], $exif['GPSLongitudeRef']);
    $lat = getGps($exif["GPSLatitude"], $exif['GPSLatitudeRef']);

    
    $uid=uniqid();
    
    $q="INSERT INTO `request`(`rid`, `city`, `pincode`, `img`, `lat`, `longi`, `date`,`status`,`acc`,`area_desc') VALUES ('$uid','$city',$pincode,'$loc2',$lat,$lon,'$ts',0,'$accid','$adisp')";
    $cmd=mysqli_query($con,$q);
    
    

    function compressedImage($source, $path, $quality) {

            $info = getimagesize($source);

            if ($info['mime'] == 'image/jpeg') 
                $image = imagecreatefromjpeg($source);

            elseif ($info['mime'] == 'image/gif') 
                $image = imagecreatefromgif($source);

            elseif ($info['mime'] == 'image/png') 
                $image = imagecreatefrompng($source);

            imagejpeg($image, $path, $quality);
    }
    
    
    function getGps($exifCoord, $hemi) {

    $degrees = count($exifCoord) > 0 ? gps2Num($exifCoord[0]) : 0;
    $minutes = count($exifCoord) > 1 ? gps2Num($exifCoord[1]) : 0;
    $seconds = count($exifCoord) > 2 ? gps2Num($exifCoord[2]) : 0;

    $flip = ($hemi == 'W' or $hemi == 'S') ? -1 : 1;
    return $flip * ($degrees + $minutes / 60 + $seconds / 3600);

    }

    function gps2Num($coordPart) {

    $parts = explode('/', $coordPart);

    if (count($parts) <= 0)
        return 0;

    if (count($parts) == 1)
        return $parts[0];
        
    return floatval($parts[0]) / floatval($parts[1]);
    }

?>