<?php

    $pas="Le704Bm7Ycf3~N@h";
    $id="id13135279_anand";
	$con=mysqli_connect("localhost",$id,$pas);
    $db=mysqli_select_db($con,"id13135279_mehsana");
?>
