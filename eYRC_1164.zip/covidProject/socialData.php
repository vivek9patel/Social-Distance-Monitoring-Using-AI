<?php

    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");

    include 'connect.php';

    $q="SELECT  `city`, `pincode`, `img`, `lat`, `longi`, `date`, `acc`, `area_desc` FROM `request`";
    $cmd=mysqli_query($con,$q);
    
    $data = array();
    
    while ($row = mysqli_fetch_array($cmd)){
        $lat=$row['lat'];
		$lon=$row['longi'];
		$link="http://maps.google.com/?q=$lat,$lon";
        
        $data[] = array("city"=>$row['city'],"pincode"=>$row['pincode'],"img"=>$row['img'],"date"=>$row['date'],"acc"=>$row['acc'],"area_desc"=>$row['area_desc'],"link"=>$link);
        //print_r($data);
    }
    echo json_encode($data);
?>