<?php
    require_once "config.php";

    /*if(isset($_SESSION['access_token'])) {
		echo "<script type='text/javascript'> document.location = 'main2.php'; </script>";
		exit();
	}*/
	
	$loginURL = $gClient->createAuthUrl();
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Covid-19</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="module" src="https://cdn.jsdelivr.net/npm/@ionic/core/dist/ionic/ionic.esm.js"></script>
    <script nomodule src="https://cdn.jsdelivr.net/npm/@ionic/core/dist/ionic/ionic.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@ionic/core/css/ionic.bundle.css"/>
    
    <style>
    :root {
      --ion-safe-area-top: 5px;
      --ion-safe-area-bottom: 22px;
    }
    #myDiv{
        position: fixed;
        width: 100%;
        height: 100vh;
        background: #fff
        url('setu_Trim.gif')
        no-repeat center;
        z-index: 99999;
        margin:auto;
        background-size:cover;
    }
     </style>
    
    </head>
<body onload="stopLoad()">
    <div id="myDiv"></div>
    <ion-app>
        <ion-header translucent>
      <ion-toolbar>
        <ion-title class="ion-text-center" color="secondary">CORONA SETU</ion-title>
      </ion-toolbar>
    </ion-header>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        
    <ion-content>
        
        <ion-card id="loginSetu" class="ion-padding">
            <ion-card-title class="ion-text-center" colcor="Dark">
                Login to Corona Setu
            </ion-card-title>
            <br>
            <!--<ion-label>&nbsp;&nbsp;</ion-label>--></ion-button></ion-burron><ion-button id="countinue" size="large" color="primary" expand="block" fill="outline" shape="round"><b>Click Here to Countinue</b></ion-button>
        </ion-card>
        <div id="forhide">
        <ion-card id="cardOTP" class="ion-padding">
            <ion-card-header>
            <ion-card-title>Mobile OTP Login</ion-card-title>
            </ion-card-header>
            <form>
            <ion-card-content>
                <ion-item lines="inset">
                    <ion-label position="floating">Enter Number</ion-label>
                    <ion-input type="number" id="mobileNumber"></ion-input>
                </ion-item>
                
                <ion-button id="getOTP" color="success" fill="outline" shape="round" class="ion-padding">Get OTP</ion-button>
                <ion-button id="cancel" color="success" fill="outline" shape="round" class="ion-padding">Cancel</ion-button>
                <ion-button id="changeNum" color="success" fill="outline" shape="round" class="ion-padding">Change Number</ion-button>
                
                <ion-item lines="inset" id="otpID" class="ion-padding">
                    <ion-label position="floating">Enter OTP</ion-label>
                    <ion-input type="number" id="otp"></ion-input>
                </ion-item>
                
                <ion-button id="ok" color="success" fill="outline" shape="round" class="ion-padding-start">Submit</ion-button>
          </ion-card-content>
          </form>
        </ion-card>
        
        <ion-button id="mobileOTP" expand="block" shape="round" color="success" fill="outline" size="large" class="ion-padding-start ion-padding-end"><ion-icon slot="start" name="call-outline"></ion-icon>Mobile OTP</ion-button>
        <br>
        <br>
        <ion-button id="google" expand="block" shape="round" color="danger" fill="outline" size="large" class="ion-padding-start ion-padding-end"><ion-icon slot="start" name="logo-google"></ion-icon>Google</ion-button>
        </div>
    </ion-content>
    </ion-app>
    <script>
        
        function stopLoad(){
                (function(){
        var myDiv = document.getElementById("myDiv"),
        
        show = function(){
            myDiv.style.display = "block";
            setTimeout(hide, 5000); // 5 seconds
        },

        hide = function(){
            myDiv.style.display = "none";
            
        };

        show();
    })();
        }
        
    
    var sentOTP;
        $('#changeNum').hide();
        $('#cardOTP').hide();
        $('#otpID').hide();
        $('#ok').hide();
        $('#mobileOTP').hide();
        $('#google').hide();
        $('#forhide').hide();
        
        $('#loginSetu').on('click',function(){
            $('#loginSetu').hide();
             $('#forhide').show();
             $('#mobileOTP').show();
        $('#google').show();
        });
        
        $("#mobileOTP").on('click',function(){
            $('#mobileOTP').hide();
            $('#google').hide();
            $('#cardOTP').show();
            $('#countinue').hide();
        });
        $('#cancel').on('click',function(){
            $('#mobileOTP').show();
            $('#google').show();
            $('#cardOTP').hide();
            //$('#countinue').hide();
        })
        
        $("#getOTP").on('click',function(){
                var number=document.getElementById("mobileNumber").value;
                $('#otpID').show();
                $('#changeNum').show();
                document.getElementById("mobileNumber").disabled = true;
                document.getElementById("getOTP").disabled = true;
                $('#ok').show();
                
                $.ajax({
                    url:"send_otp.php",
                    method:"POST",
                    data:{mobile_number:number},
                    success:function(data)
                    {
                        sentOTP=data;
                        console.log(sentOTP);
                    }
                });
        });
        
        $('#changeNum').on('click',function(){
            document.getElementById("mobileNumber").disabled = false;
            $('#otpID').hide();
            $('#changeNum').hide();
            $('#ok').hide();
            document.getElementById("getOTP").disabled = false;
        });
        
        $('#ok').on('click',function(){
            var otp=document.getElementById("otp").value;
            console.log(sentOTP);
            if(otp == sentOTP){
                 location.replace("http://indiafightscovid19.000webhostapp.com/main.php");
            }
            else{
                alert("not valid");
            }
        });
        
        $('#google').on('click',function(){
             location.replace("<?php echo $loginURL;?>");
        });
     
    
  </script>
</body>
</html>