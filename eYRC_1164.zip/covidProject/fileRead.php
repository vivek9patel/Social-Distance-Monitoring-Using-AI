<?php
/*$myfile="database.txt";
//echo readfile($myfile);

$file = fopen($myfile,"r");
echo fgets($file,1000);
fclose($file);

while(!feof($myfile)) {
  echo fgetc($myfile);
}

/*$myfile = fopen($my, "r") or die("Unable to open file!");

echo "<table>";
while(!feof($myfile)) {
  echo "<tr><td width='600' bgcolor='#fffff'>";
  echo fgets($myfile) . "<br>";
  echo "</td></tr>";
}
echo "</table>";
fclose($myfile);

echo "hello";*/
?>

<?php
header("Content-type: text/html");
echo "<html>
<head>
<meta charset='UTF-8'>
<meta name='viewport' content='width=device-width, initial-scale=1.0'>
<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js'></script>
</head>
<body>
<button onclick='goBack()'>Back</button>
";
 
$file = fopen("database.txt","r") or die("Error");
?>
 
<table border=1>
	<tr>
		<th>TimeStamp</th>
		<th>Persons</th>
		<th>Location</th>
		<th>Mask</th>
	</tr>
	
<?php
 
while(($row = fgets($file)) != false) {
	echo "<tr>";
	$col = explode('|',$row);
	//$col =explode('|',$col);
	
	//print_r($col);
	foreach($col as $data) {
			echo "<td>". trim($data,"TimeStamp Persons Location Mask")."</td>";
	}
	echo "</tr>";
}
?>
 
</table>
<script>
function goBack() {
          window.history.back();
        }
</script>
</body>
</html>